<div align="center">

```
 ______
|___  /
   / / _   _  _ __  ___  _ __   _   _  ___
  / / | | | || '__|/ _ \| '_ \ | | | |/ __|
 / /__| |_| || |  | (_) | | | || |_| |\__ \
/_____|__, ||_|   \___/ |_| |_| \__,_||___/
        __/ |
       |___/
```

**Systems Architect · AI Infrastructure · Full-Stack Engineer**

[![Portfolio](https://img.shields.io/badge/zyronis.com-000000?style=for-the-badge&logo=vercel&logoColor=white)](https://zyronis.com)
[![WhatsApp](https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/2348151613794)
[![Discord](https://img.shields.io/badge/Discord-5865F2?style=for-the-badge&logo=discord&logoColor=white)](https://discord.com/users/emmanuelzyronis)

</div>

---

### What I build

I design and ship **AI-powered business infrastructure** — the kind of systems that sit at the intersection of real-time data, intelligent routing, and enterprise-grade reliability.

My work spans the full stack, from distributed backend architecture to polished production frontends. I don't build demos. I build things that run.

---

### Current focus

```
▸ Abyssal Dispatch     —  Field agent routing engine (Rust · Kafka · Postgres · Redis)
▸ Zyronis School Engine —  Institutional management platform (Next.js · Supabase · TypeScript)
▸ Cash Engine          —  Revenue acceleration tooling for businesses
▸ Logistics Brain      —  AI-driven supply chain decision layer
```

> Most work lives in private repositories. What I ship, I protect.

---

### Stack

**Backend**
`Rust` `Node.js` `Kafka` `PostgreSQL` `Redis` `ClickHouse` `Supabase`

**Frontend**
`Next.js` `TypeScript` `Framer Motion` `Tailwind CSS` `React Three Fiber`

**Infrastructure**
`Docker` `Vercel` `GitHub Actions` `REST · WebSockets · SSE`

---

### Philosophy

> *Infrastructure is invisible when it works. My job is to make sure it always works.*

I build for scale, for clarity, and for the long run. No shortcuts on architecture. No excuses on reliability.

---

<div align="center">

**Open to select partnerships and consulting engagements.**

[→ Let's talk](https://zyronis.com/#contact)

</div>
